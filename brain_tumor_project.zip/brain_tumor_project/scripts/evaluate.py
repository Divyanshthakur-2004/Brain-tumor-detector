import matplotlib.pyplot as plt
from tensorflow.keras.models import load_model
import data_preprocessing

dataset_path = '../dataset_directory'  # Adjusted the path
img_width, img_height = 150, 150

# Data Generators
_, validation_generator = data_preprocessing.get_data_generators(dataset_path, img_width, img_height)

# Load the trained model
model = load_model('brain_tumor_detector.h5')

# Model Evaluation
loss, accuracy = model.evaluate(validation_generator)
print(f'Validation Accuracy: {accuracy*100:.2f}%')

# Plotting accuracy and loss curves
history = model.history.history

plt.plot(history['accuracy'], label='Training Accuracy')
plt.plot(history['val_accuracy'], label='Validation Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()
plt.show()

plt.plot(history['loss'], label='Training Loss')
plt.plot(history['val_loss'], label='Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()
plt.show()
