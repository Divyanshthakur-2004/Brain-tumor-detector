from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np

img_width, img_height = 150, 150

# Load the trained model
model = load_model('brain_tumor_detector.h5')

# Function to predict on new images 
def predict_image(img_path):
    img = image.load_img(img_path, target_size=(img_width, img_height))
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0) / 255.0
    prediction = model.predict(img_array)
    return 'Tumor Detected' if prediction[0][0] > 0.5 else 'No Tumor'

# Example usage
result = predict_image(r'C:\Users\HP\Desktop\brain_tumor_project\images\no\3 no.jpg')

print(result)






# import tensorflow as tf

# print("TensorFlow version:", tf.__version__)