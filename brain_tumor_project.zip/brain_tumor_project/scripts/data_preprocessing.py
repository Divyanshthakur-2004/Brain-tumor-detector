import os
from tensorflow.keras.preprocessing.image import ImageDataGenerator

def get_data_generators(dataset_path, img_width, img_height):
    datagen = ImageDataGenerator(
        rescale=1./255,
        validation_split=0.2,
        rotation_range=20,
        width_shift_range=0.2,
        height_shift_range=0.2,
        shear_range=0.2,
        zoom_range=0.2,
        horizontal_flip=True,
        fill_mode='nearest'
    )
    train_generator = datagen.flow_from_directory(
        os.path.join(dataset_path, 'training'),
        target_size=(img_width, img_height),
        batch_size=32,
        class_mode='binary'
    )
    validation_generator = datagen.flow_from_directory(
        os.path.join(dataset_path, 'validation'),
        target_size=(img_width, img_height),
        batch_size=32,
        class_mode='binary'
    )
    return train_generator, validation_generator

# Example usage
dataset_path = '../dataset_directory'  # Adjusted the path
img_width, img_height = 150, 150
train_generator, validation_generator = get_data_generators(dataset_path, img_width, img_height)
