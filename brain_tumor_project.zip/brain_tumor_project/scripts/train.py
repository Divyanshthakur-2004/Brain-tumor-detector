import data_preprocessing
import model

dataset_path = '../dataset_directory'  # Adjusted the path
img_width, img_height = 150, 150

# Data Generators
train_generator, validation_generator = data_preprocessing.get_data_generators(dataset_path, img_width, img_height)

# Model Creation
model = model.create_model(img_width, img_height)

# Model Training
history = model.fit(
    train_generator,
    steps_per_epoch=train_generator.samples // train_generator.batch_size,
    validation_data=validation_generator,
    validation_steps=validation_generator.samples // validation_generator.batch_size,
    epochs=10
)

# Save the trained model
model.save('brain_tumor_detector.h5')
